/* Estimate the percolation threshold p* */

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private int[][] grid;
    private int gridOrder;
    private int virtualArrayOrder;
    private int openCount;
    private WeightedQuickUnionUF weightedQuickUnionUF;

    private static int twoDimensionalPairToArrayIndex(int row, int col, int order) {
        return (row * order) + col + 1;
    }

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        if (n < 1) {
            throw new IllegalArgumentException("n must be greater than 0.");
        }

        gridOrder = n;
        grid = new int[gridOrder][gridOrder];

        virtualArrayOrder = (gridOrder * gridOrder) + 2;

        weightedQuickUnionUF = new WeightedQuickUnionUF(virtualArrayOrder);

        // connect only first grid to virtual top node
        for (int i = 0; i < gridOrder; i++) {
            weightedQuickUnionUF.union(0, i + 1);
        }
        // connect only last grid to virtual bottom node
        for (int i = virtualArrayOrder - 2; i > (gridOrder * (gridOrder - 1)); i--) {
            weightedQuickUnionUF.union(i, virtualArrayOrder - 1);
        }
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        if (isOpen(row, col)) {
            return;
        }

        grid[row][col] = 1;
        openCount++;

        // merge the opened site to neighbors components, if any
        for (int r = row - 1; r <= row + 1; r++) {
            for (int c = col - 1; c <= col + 1; c++) {
                // prevent self union
                if (r == row && c == col) {
                    continue;
                }

                // out of bounds
                if (r < 0 || r >= gridOrder || c < 0 || c >= gridOrder) {
                    continue;
                }

                // diagonals
                if ((r == row - 1) && ((c == col - 1) || (c == col + 1))) {
                    continue;
                } else if ((r == row + 1) && ((c == col - 1) || (c == col + 1))) {
                    continue;
                }

                // finally, if not blocked
                if (grid[r][c] == 1) {
                    int p = twoDimensionalPairToArrayIndex(row, col, gridOrder);
                    int q = twoDimensionalPairToArrayIndex(r, c, gridOrder);
                    weightedQuickUnionUF.union(p, q);
                }
            }
        }
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        return grid[row][col] == 1;
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        if (isOpen(row, col)) {
            if (weightedQuickUnionUF.find(twoDimensionalPairToArrayIndex(row, col, gridOrder)) == weightedQuickUnionUF.find(0)) {
                return true;
            }
        }

        return false;
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return openCount;
    }

    private void printGrid() {
        for (int[] ints : grid) {
            for (int anInt : ints) {
                System.out.print(anInt);
            }
            System.out.println();
        }
    }

    private void printUF() {
        System.out.println(" " + weightedQuickUnionUF.find(0));
        for (int i = 1; i <= virtualArrayOrder - 2; i++) {
            System.out.print(weightedQuickUnionUF.find(i));
            if (i % 3 == 0) {
                System.out.println();
            }
        }
        System.out.println(" " + weightedQuickUnionUF.find(virtualArrayOrder - 1));
    }

    // does the system percolate?
    public boolean percolates() {
        return weightedQuickUnionUF.find(0) == weightedQuickUnionUF.find(virtualArrayOrder - 1);
    }

    // test client (optional)
    public static void main(String[] args) {
    }
}
