import edu.princeton.cs.algs4.StdRandom;

import java.util.ArrayList;

public class PercolationStats {
    int iterations;
    int gridOrder;
    double percolationThresholdAvg = 0;
    ArrayList<Double> percolationThresholds = new ArrayList<>(30);

    // perform independent trials on an n-by-n grid
    public PercolationStats(int n, int trials) {
        gridOrder = n;
        iterations = trials;

        for (int i = 0; i < trials; i++) {
            Percolation percolation = new Percolation(gridOrder);

            while (!percolation.percolates()) {
                int row = StdRandom.uniformInt(0, gridOrder);
                int col = StdRandom.uniformInt(0, gridOrder);
                if (!percolation.isOpen(row, col)) {
                    percolation.open(row, col);
                }
            }

            int openCount = percolation.numberOfOpenSites();

            double percolationThreshold = (double) (openCount) / (double) (gridOrder * gridOrder);
            percolationThresholds.add(percolationThreshold);
            percolationThresholdAvg += percolationThreshold;
        }

        percolationThresholdAvg /= iterations;
    }

    // sample mean of percolation threshold
    public double mean() {
        return percolationThresholdAvg;
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        double variance = 0;

        for (Double percolationThreshold : percolationThresholds) {
            variance += Math.pow((percolationThreshold - mean()), 2);
        }

        variance /= iterations - 1;

        return Math.sqrt(variance);
    }

    // low endpoint of 95% confidence interval
    public double confidenceLo() {
        return (mean()) - (1.96 * (stddev()) / (Math.sqrt(iterations)));
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        return (mean()) + (1.96 * (stddev()) / (Math.sqrt(iterations)));
    }

    // test client (see below)
    public static void main(String[] args) {
        PercolationStats ps = new PercolationStats(Integer.parseInt(args[0]), Integer.parseInt(args[1]));

        double mean = ps.mean();
        double stddev = ps.stddev();
        double[] confidenceInterval = {ps.confidenceLo(), ps.confidenceHi()};

        String format = "%-24s= %s%n";

        System.out.printf(format, "mean", mean);
        System.out.printf(format, "stddev", String.format("%.16f", stddev));
        System.out.printf(format, "96% confidence interval", String.format("[%.16f, %.16f]", confidenceInterval[0], confidenceInterval[1]));
    }

}
